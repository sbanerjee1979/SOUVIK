package testMaven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class test {

	WebDriver driver;

	@BeforeTest
	public void OpenAUT() {
		// Open Browser
		System.setProperty("webdriver.chrome.driver", "C:\\Program Files\\Selenium\\drivers\\chromedriver_2.46.exe");
		driver = new ChromeDriver();
		
		// Open AUT
		driver.get("https://www.google.com");

	}

	@Test
	public void ValidateTitle() {
		// Get the Actual title
		String Apptitle = driver.getTitle();

		System.out.println(Apptitle);

		// Validate the actual title with expected title
		boolean result = Apptitle.equals("Google");

		System.out.println(result);
	}
	@AfterSuite
	public void CloseBrowser() {
		driver.quit();
	}

}
